<?php
session_start();
//Connexion à la base de données
$dsn = 'mysql:dbname=mangas;host=127.0.0.1';
$hote = 'localhost';
$user = 'root';
$password = '';

try{
    $dbh = new PDO($dsn,$user,$password);
    $titre = "Connexion";
} catch (PDOException $e){
    echo 'Connexion échouée : ' . $e->getMessage();
}

?>