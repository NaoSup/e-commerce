<!-- Table de confirmation d'utilisateurs après inscription
Page qui n'est accessible que par un utilisateur défini(dans ce cas j'ai choisis le pseudo 'exemple' que j'avais inscrit dans ma base de données.
Après à toi de voir -->
<?php
require("connexionbdd.php");

if(empty($_SESSION['user-connecté'])){
    header('Location: connexion.php');
} else {


#echo '<script type="text/javascript"> alert("Bienvenue");</script>';
?>

<?php
require("connexionbdd.php");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>

    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <script src="http://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js"></script>
    <script src="js/fonts.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/icons.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/owl.carousel.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />
    <link rel="stylesheet" href="css/custom.css" />
    <link rel="stylesheet" href="css/connexion.css" />
</head>
<body class="dark-page">

<div id="preloader"><div class="circles"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>

<?php #A revoir
?>

<nav id="nav-logo-menu-btn-2" class="navbar dark navbar-fixed-top" style="">
    <div class="container">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        </div>

        <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="index.php"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Accueil</font></font></font></font></font></font></font></font></span></a></li>
                <li class=""><a href="boutique.php"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Boutique</font></font></font></font></font></font></font></font></span></a></li>
                <li class=""><a href="profil.php"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Profil</font></font></font></font></font></font></font></font></span></a></li>
                <li class=""><a href="userconfirm.php"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Confirmation</font></font></font></font></font></font></font></font></span></a></li>
            </ul>
            <div class="btn-group navbar-right">
                <?php if(isset($_SESSION['user-connecté'])) { } else { ?> <a href="inscription.php" class="btn-link btn btn-sm navbar-btn"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Inscription</font></font></font></font></font></font></font></font></span></a> <?php } ?>
                <?php if(isset($_SESSION['user-connecté'])){
                    ?><a href="deconnexion.php" class="btn-link btn btn-sm navbar-btn"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Deconnexion</font></font></font></font></font></font></font></font></span></a>
                <?php } else { ?>
                    <a href="connexion.php" class="btn-link btn btn-sm navbar-btn"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Connexion</font></font></font></font></font></font></font></font></span></a>
                <?php } ?>
                <a href="panier.php" class="btn-primary btn btn-sm navbar-btn"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Panier </font></font></font></font></font></font></font></font></span></a>
                <?php if(isset($_SESSION['user-connecté'])){ ?>                 <a class="btn-link btn btn-sm navbar-btn"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?php echo $_SESSION['user-connecté']; ?></font></font></font></font></font></font></font></font></span></a> <?php } ?>
            </div>
        </div>

    </div>

    <div class="nav-bg dark"></div>
</nav>

<div id="wrap">
    <section id="contact-halfbg-form" class="pt-md-125 pb-125 bg-1-color-light light">
        <!-- <div class="half-container-left"></div> -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 col-md-offset-7">
                    <h2 class="mb-20"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Confirmation de comptes</font></font></font></font></font></font></font></font></h2>
                    <?php

                    $quete = $dbh->query('SELECT * FROM utilisateurs');
                    while($validation = $quete->fetch()){
                        echo 'Pseudo: ';
                        echo $validation['pseudo'].'<br>';
                        echo 'Mot de passe: ';
                        echo $validation['password'].'<br>';
                        echo 'E-mail: ';
                        echo $validation['email'].'<br>';
                        echo '<button type="submit"><a href="userconfirm.php?action=accepter&id_utilisateur='.$validation['id_utilisateur'].'">Accepter</a></button> ';
                        echo '<button type="submit"><a href="userconfirm.php?action=refuser&id_utilisateur='.$validation['id_utilisateur'].'">Refuser</a></button>';
                        echo '<br/><br />';
                    }

                    if(isset($_GET['action']) AND isset($_GET['id_utilisateur']))
                    {
                        $action = $_GET['action'];
                        if($action == "accepter")
                        {
                            $id = $_GET['id_utilisateur'];
                            $quete2 = $dbh->query("SELECT * FROM utilisateurs WHERE id_utilisateur='$id'");
                            $connexion = $quete2->fetch();
                            $pseudo = $connexion['pseudo'];
                            $password = $connexion['password'];
                            $email = $connexion['email'];
                            $dbh->query("INSERT INTO connexion VALUES('$id', '$pseudo', '$password', '$email')");
                            $dbh->query("DELETE FROM utilisateurs WHERE id_utilisateur='$id'");
                        }
                        elseif($action == "refuser")
                        {
                            $id = $_GET['id_utilisateur'];
                            $dbh->query("DELETE FROM utilisateurs WHERE id_utilisateur='$id'");
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="bg"></div>
    </section>
</div>
<?php
include "footer.php";
?>
</div>
<footer></footer>
<div class="modal-container"></div>
<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.vide.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCByts0vn5uAYat3aXEeK0yWL7txqfSMX8"></script>
<script src="https://cdn.jsdelivr.net/jquery.goodshare.js/3.2.8/goodshare.min.js"></script>
<script src="js/custom.js"></script>
<script src="js/connexion.js"></script>
</body>
</html>

<?php } ?>