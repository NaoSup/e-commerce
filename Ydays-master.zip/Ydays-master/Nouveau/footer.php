<footer id="footer-center-social-logo" class="dark pt-100 pb-100 text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ul class="social-list">
                    <li>
                        <a href="#"><i class="icon-twitter icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-facebook icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-linkedin icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-github-alt icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-pinterest-p icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-google-plus icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-dribbble icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-behance icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-instagram icon-size-m"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="icon-youtube icon-size-m"></i></a>
                    </li>
                </ul>
                <p class="mt-20"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">© Multifour.com. </font><font style="vertical-align: inherit;">Tous les droits sont réservés.</font></font></p>
                <div>
                    <img src="../images/logo-mid.png" srcset="../images/logo-mid@2x.png 2x" alt="Votre logo" class="mt-50">
                </div>
            </div>
        </div>
    </div>
    <div class="bg"></div>
</footer>