<?php
include "connexionbdd.php";
#require "user.php";
//Poster un commentaire
if(isset($_POST['titre']) and isset($_FILES['image']))
{

    $req = $dbh->prepare('INSERT INTO articless (titre, texte, id_utilisateur) VALUES (?,?,?)');
    $req->execute([$_POST['titre'],$_POST['description'],$_SESSION['user-connecté']]);
    //--$req->execute(array($_POST['content'],$_SESSION['utilisateur-connecté']));
    //echo $_POST['content'];
    // On récupère des informations du fichier
    $nom_fichier = $_FILES['image']['name'];
    $chemin_temporaire = $_FILES['image']['tmp_name'];

    // On définit le nouveau chemin avec le repertoire images suivi du lien du fichier(exemple: identifiants.txt)
    $nouveau_chemin = 'pictures/' . $nom_fichier;
    // On déplace le fichier dans le dossier images
    move_uploaded_file($chemin_temporaire, $nouveau_chemin);

    // On affiche l'image
    echo '<img src="' . $nouveau_chemin . '">';

/*    $req1 = $dbh->query("SELECT * FROM articles");
    $articles = $req1->fetchAll();

    foreach($articles as $article){
        echo $article['titre'] ."<br>";
    }*/
}
?>

<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="script.css">
    <title>Publication</title>
</head>
<body>
<header></header>
<form method=post id="main">
    <input type="text" name="titre" placeholder="Titre" maxlenght="280"><br />
    <input type="file" class="form-control" name="image"><br />
    <button class="article button" type="submit">Publier</button>
</form>
</body>
</html>
