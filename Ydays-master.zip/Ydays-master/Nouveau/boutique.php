<?php
require("connexionbdd.php");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Boutique</title>
		
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
		<script src="http://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js"></script>
		<script src="js/fonts.js"></script>
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link rel="stylesheet" href="css/icons.css" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/owl.carousel.css" />
		<link rel="stylesheet" href="css/magnific-popup.css" />
		<link rel="stylesheet" href="css/custom.css" />
		<link rel="stylesheet" href="css/boutique.css" />
	</head>
    <body class="light-page">
    <?php
    include "header.php";
    ?>
    <div id="wrap">
			<section id="desc-fluid-card-5col" class="pt-100 pb-0 dark text-center">
    			<div class="container-fluid pad-x2">
        			<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Derniers messages</font></font></h2>
        			<h3 class="mb-75"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Messages et photos des endroits les plus intéressants</font></font></h3>
        			<div class="row">
            			<div class="col-md-4 col-lg-20 mb-60">
                			<div class="card shadow-box light" style="background-color:#ffffff">
                    			<img src="images/screen-57.jpg" srcset="images/screen-57@2x.jpg 2x" alt="Photo" class="card-img-top">
                    			<div class="card-block padding-box">
                        			<h4><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Design moderne</font></font></strong></h4>
                        			<p class="mb-30 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Votre projet est superbe sur n'importe quel appareil. </font><font style="vertical-align: inherit;">Le contenu peut être facilement lu et un utilisateur comprend librement ce que vous vouliez</font></font></p>
                        			<a class="btn btn-primary btn-sm" href="#"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Commandez maintenant</font></font></span></a>
                    			</div>
                			</div>
            			</div>
            			<div class="col-md-4 col-lg-20 mb-60">
                			<div class="card shadow-box light" style="background-color:#ffffff">
                    			<img src="images/screen-58.jpg" srcset="images/screen-58@2x.jpg 2x" alt="Photo" class="card-img-top">
                    			<div class="card-block padding-box">
                        			<h4><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">La technologie</font></font></strong></h4>
                        			<p class="mb-30 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Votre projet est superbe sur n'importe quel appareil. </font><font style="vertical-align: inherit;">Le contenu peut être facilement lu et un utilisateur comprend librement ce que vous vouliez</font></font></p>
                        			<a class="btn btn-primary btn-sm" href="#"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Commandez maintenant</font></font></span></a>
                    			</div>
                			</div>
            			</div>
            			<div class="col-md-4 col-lg-20 mb-60">
                			<div class="card shadow-box light" style="background-color:#ffffff">
                    			<img src="images/screen-59.jpg" srcset="images/screen-59@2x.jpg 2x" alt="Photo" class="card-img-top">
                    			<div class="card-block padding-box">
                        			<h4><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">La flexibilité</font></font></strong></h4>
                        			<p class="mb-30 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Votre projet est superbe sur n'importe quel appareil. </font><font style="vertical-align: inherit;">Le contenu peut être facilement lu et un utilisateur comprend librement ce que vous vouliez</font></font></p>
                        			<a class="btn btn-primary btn-sm" href="#"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Commandez maintenant</font></font></span></a>
                    			</div>
                			</div>
            			</div>
            			<div class="col-md-4 col-lg-20 mb-60">
                			<div class="card shadow-box light" style="background-color:#ffffff">
                    			<img src="images/screen-60.jpg" srcset="images/screen-60@2x.jpg 2x" alt="Photo" class="card-img-top">
                    			<div class="card-block padding-box">
                        			<h4><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Nouvelle interface</font></font></strong></h4>
                        			<p class="mb-30 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Votre projet est superbe sur n'importe quel appareil. </font><font style="vertical-align: inherit;">Le contenu peut être facilement lu et un utilisateur comprend librement ce que vous vouliez</font></font></p>
                        			<a class="btn btn-primary btn-sm" href="#"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Commandez maintenant</font></font></span></a>
                    			</div>
                			</div>
            			</div>
            			<div class="col-md-4 col-lg-20 mb-60">
                			<div class="card shadow-box light" style="background-color:#ffffff">
                    			<img src="images/screen-61.jpg" srcset="images/screen-61@2x.jpg 2x" alt="Photo" class="card-img-top">
                    			<div class="card-block padding-box">
                        			<h4><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Innovations</font></font></strong></h4>
                        			<p class="mb-30 small"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Votre projet est superbe sur n'importe quel appareil. </font><font style="vertical-align: inherit;">Le contenu peut être facilement lu et un utilisateur comprend librement ce que vous vouliez</font></font></p>
                        			<a class="btn btn-primary btn-sm" href="#"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Commandez maintenant</font></font></span></a>
                    			</div>
                			</div>
            			</div>
        			</div>
        			<div class="bg"></div>
    			</div>
			</section>

        <?php
        include "footer.php";
        ?>

		</div>
		<footer></footer>
		<div class="modal-container"></div>
		<script src="js/jquery-2.1.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.vide.min.js"></script>
		<script src="js/owl.carousel.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
		<script src="js/jquery.validate.min.js"></script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCByts0vn5uAYat3aXEeK0yWL7txqfSMX8"></script>
		<script src="https://cdn.jsdelivr.net/jquery.goodshare.js/3.2.8/goodshare.min.js"></script>
		<script src="js/custom.js"></script>
		<script src="js/boutique.js"></script>
	</body>
</html>