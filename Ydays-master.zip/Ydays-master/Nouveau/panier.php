<?php
require("connexionbdd.php");
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Panier</title>
		
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
		<script src="http://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js"></script>
		<script src="js/fonts.js"></script>
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link rel="stylesheet" href="css/icons.css" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/owl.carousel.css" />
		<link rel="stylesheet" href="css/magnific-popup.css" />
		<link rel="stylesheet" href="css/custom.css" />
		<link rel="stylesheet" href="css/panier.css" />
	</head>
    <body class="dark-page">
    <?php
    include "header.php";
    ?>

    <div id="wrap">
			<section id="desc-text-list-quartbg" class="pt-125 pb-md-125 dark">
    			<div class="container">
        			<div class="row">
            			<div class="col-md-4">
                			<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Modèle flexible</font></font></h2>
                			<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Voulez-vous créer un nouveau projet ou mettre à jour le précédent? </font><font style="vertical-align: inherit;">Donc, ce modèle vous correspondra idéalement. </font><font style="vertical-align: inherit;">Des solutions innovantes et un calcul mathématique simple et calculé le rendent effectif pour longtemps.</font></font></p>
            			</div>
            			<div class="col-md-3 col-md-offset-1">
                			<ul class="text-icon-list text-icon-list-sep">
                    			<li class="clearfix"><i class="icon-zoom-in icon-color icon-size-m icon-position-left"></i>
                        			<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Zoom </font></font></span>
                        			<span class="pull-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">x20</font></font></span>
                    			</li>
                    			<li class="clearfix"><i class="icon-battery-mid1 icon-color icon-size-m icon-position-left"></i>
                        			<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Batterie </font></font></span>
                        			<span class="pull-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Lithium-ion</font></font></span>
                    			</li>
                    			<li class="clearfix"><i class="icon-frame-expand icon-color icon-size-m icon-position-left"></i>
                        			<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Megapixels </font></font></span>
                        			<span class="pull-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">25 MP</font></font></span>
                    			</li>
                    			<li class="clearfix"><i class="icon-cable icon-color icon-size-m icon-position-left"></i>
                        			<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Connectivité </font></font></span>
                        			<span class="pull-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">USB</font></font></span>
                    			</li>
                    			<li class="clearfix"><i class="icon-tag icon-color icon-size-m icon-position-left"></i>
                        			<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Prix </font></font></span>
                        			<span class="pull-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">899 $</font></font></span>
                    			</li>
                			</ul>
            			</div>
        			</div>
    			</div>
    			<div class="quarter-container-right"></div>
    			<div class="bg bg-video" data-vide-bg="mp4: video/abstract_video_2.mp4, ogv: , jpg: " data-vide-options="posterType: jpg"></div>
			</section><section id="contact-center-form" class="pt-125 pb-125 dark text-center">
    			<div class="container">
        			<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Écrivez-nous</font></font></h2>
        			<h4 class="mb-50"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vous êtes très important pour nous, toutes les informations reçues resteront toujours confidentielles.</font></font></h4>
        			<div class="row">
            			<div class="col-md-12">
                			<form action="./scripts/request.php" class="contact_form" novalidate="novalidate" id="contact-center-form-form">
                    			<div class="form-group">
                        			<input type="text" class="form-control" placeholder="Full name" name="NAME">
                    			</div>
                    			<div class="form-group">
                        			<input type="email" class="form-control" placeholder="Email Address" name="EMAIL">
                    			</div>
                    			<div class="form-group">
                        			<textarea class="form-control" rows="6" placeholder="Your message or question" name="MESSAGE"></textarea>
                    			</div>
                    			<button type="submit" data-loading-text="•••" data-complete-text="Completed!" data-reset-text="Try again later..." class="btn btn-primary"><i class="icon-paper-plane icon-position-left icon-size-m"></i><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Envoyer le message</font></font></span></button>
                			</form>
            			</div>
        			</div>
    			</div>
    			<div class="bg bg-video" data-vide-bg="mp4: video/abstract_video_2.mp4, ogv: , jpg: " data-vide-options="posterType: jpg"></div>
			</section><section id="clients-fluid-6col" class="pt-50 pb-50 dark text-center">
    			<div class="container-fluid">
        			<div class="row">
            			<div class="col-md-2 col-sm-4">
                			<div class="card card-simple">
                    			<a href="#">
                        			<img class="screen" src="images/client-1.png" srcset="images/client-1@2x.png 2x" alt="Client">
                    			</a>
                			</div>
            			</div>
            			<div class="col-md-2 col-sm-4">
                			<div class="card card-simple">
                    			<a href="#">
                        			<img class="screen" src="images/client-2.png" srcset="images/client-2@2x.png 2x" alt="Client">
                    			</a>
                			</div>
            			</div>
            			<div class="col-md-2 col-sm-4">
                			<div class="card card-simple">
                    			<a href="#">
                        			<img class="screen" src="images/client-3.png" srcset="images/client-3@2x.png 2x" alt="Client">
                    			</a>
                			</div>
            			</div>
            			<div class="col-md-2 col-sm-4">
                			<div class="card card-simple">
                    			<a href="#">
                        			<img class="screen" src="images/client-4.png" srcset="images/client-4@2x.png 2x" alt="Client">
                    			</a>
                			</div>
            			</div>
            			<div class="col-md-2 col-sm-4">
                			<div class="card card-simple">
                    			<a href="#">
                        			<img class="screen" src="images/client-5.png" srcset="images/client-5@2x.png 2x" alt="Client">
                    			</a>
                			</div>
            			</div>
            			<div class="col-md-2 col-sm-4">
                			<div class="card card-simple">
                    			<a href="#">
                        			<img class="screen" src="images/client-8.png" srcset="images/client-8@2x.png 2x" alt="Client">
                    			</a>
                			</div>
            			</div>
        			</div>
    			</div>
    			<div class="bg"></div>
			</section>

    <?php
    include "footer.php";
    ?>
		</div>
		<footer></footer>
		<div class="modal-container"></div>
		<script src="js/jquery-2.1.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.vide.min.js"></script>
		<script src="js/owl.carousel.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
		<script src="js/jquery.validate.min.js"></script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCByts0vn5uAYat3aXEeK0yWL7txqfSMX8"></script>
		<script src="https://cdn.jsdelivr.net/jquery.goodshare.js/3.2.8/goodshare.min.js"></script>
		<script src="js/custom.js"></script>
		<script src="js/panier.js"></script>
	</body>
</html>