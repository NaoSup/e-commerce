<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Profil</title>
		
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<meta name="viewport" content="width=device-width,initial-scale=1.0">
		<script src="http://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js"></script>
		<script src="js/fonts.js"></script>
		<link rel="stylesheet" href="css/bootstrap.css" />
		<link rel="stylesheet" href="css/icons.css" />
		<link rel="stylesheet" href="css/style.css" />
		<link rel="stylesheet" href="css/owl.carousel.css" />
		<link rel="stylesheet" href="css/magnific-popup.css" />
		<link rel="stylesheet" href="css/custom.css" />
		<link rel="stylesheet" href="css/profil.css" />
	</head>
    <body class="dark-page">
    <?php
    include "header.php";
    ?>

		<div id="wrap">
			<section id="contact-quartbg-form-text" class="pt-md-150 pb-150 bg-1-color-light light">
   			<div class="quarter-container-left"></div>
    			<div class="container-fluid">
        			<div class="row">
            			<div class="col-md-4 col-md-offset-4">
                			<h2 class="mb-50"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Écrivez-nous </font></font></h2>
                			<form action="./scripts/request.php" class="contact_form" novalidate="novalidate" id="contact-quartbg-form-text-form">
                    			<div class="form-group">
                        			<input type="text" class="form-control" placeholder="Full name" name="NAME">
                    			</div>
                    			<div class="form-group">
                        			<input type="email" class="form-control" placeholder="Email Address" name="EMAIL">
                    			</div>
                    			<div class="form-group">
                        			<textarea class="form-control" rows="6" placeholder="Your message or question" name="MESSAGE"></textarea>
                    			</div>
                    			<button type="submit" data-loading-text="•••" data-complete-text="Completed!" data-reset-text="Try again later..." class="btn btn-block btn-primary"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Demander</font></font></span></button>
                			</form>
            			</div>
            			<div class="col-md-3">
                			<h2 class="mb-50"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Emplacement</font></font></h2>
                			<p class="mb-50"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Suivez-nous sur les réseaux sociaux. </font><font style="vertical-align: inherit;">Vous pouvez également vous abonner à nos nouvelles. </font><font style="vertical-align: inherit;">Nous allons vous fournir des informations réelles et importantes pour vous, sans spam ni pourfil.</font></font></p>
                			<ul class="text-icon-list">
                    			<li><i class="icon-map2"></i><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Notre adresse de lieu</font></font></span></li>
                    			<li><i class="icon-at-sign"></i><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Notre Email</font></font></span></li>
                    			<li><i class="icon-phone-incoming"></i><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Notre téléphone</font></font></span></li>
                    			<li><i class="icon-clock"></i><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Nos heures de travail</font></font></span></li>
                			</ul>
            			</div>
        			</div>
    			</div>
    			<div class="bg"></div>
			</section><section id="team-text-3col-2row" class="pt-150 pb-150 light">
    			<div class="container">
        			<div class="row">
            			<div class="col-md-3">
                			<h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Équipe</font></font></h2>
                			<p class="mb-50"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Dans notre travail, nous essayons de n'utiliser que les solutions les plus modernes, pratiques et intéressantes.</font></font></p>
                			<a href="#" class="btn btn-default"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Contactez nous</font></font></span><i class="icon-feather icon-size-m  icon-position-right"></i></a>
            			</div>
            			<div class="col-md-3">
                			<div class="card">
                    			<div class="card-block-hover">
                        			<div class="card-img-overlay-center card-img-overlay-bg">
                            			<ul class="social-list">
                                			<li><a href="#"><i class="icon-twitter icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-facebook icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-linkedin icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-google-plus icon-size-m"></i></a></li>
                            			</ul>
                        			</div>
                        			<img class="card-img" src="images/team-2.jpg" srcset="images/team-2@2x.jpg 2x" alt="équipe">
                    			</div>
                    			<div class="card-block">
                        			<h4 class="mt-20 mb-0"><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Laura O'Neil</font></font></strong></h4>
                        			<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Directeur</font></font></p>
                    			</div>
                			</div>
                			<div class="card">
                    			<div class="card-block-hover">
                        			<div class="card-img-overlay-center card-img-overlay-bg">
                            			<ul class="social-list">
                                			<li><a href="#"><i class="icon-twitter icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-facebook icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-linkedin icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-google-plus icon-size-m"></i></a></li>
                            			</ul>
                        			</div>
                        			<img class="card-img" src="images/team-1.jpg" srcset="images/team-1@2x.jpg 2x" alt="équipe">
                    			</div>
                    			<div class="card-block">
                        			<h4 class="mt-20 mb-0"><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Michael Smith</font></font></strong></h4>
                        			<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Designer</font></font></p>
                    			</div>
                			</div>
            			</div>
            			<div class="col-md-3">
                			<div class="card">
                    			<div class="card-block-hover">
                        			<div class="card-img-overlay-center card-img-overlay-bg">
                            			<ul class="social-list">
                                			<li><a href="#"><i class="icon-twitter icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-facebook icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-linkedin icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-google-plus icon-size-m"></i></a></li>
                            			</ul>
                        			</div>
                        			<img class="card-img" src="images/team-3.jpg" srcset="images/team-3@2x.jpg 2x" alt="équipe">
                    			</div>
                    			<div class="card-block">
                        			<h4 class="mt-20 mb-0"><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Katy Davis</font></font></strong></h4>
                        			<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Programmeur</font></font></p>
                    			</div>
                			</div>
                			<div class="card">
                    			<div class="card-block-hover">
                        			<div class="card-img-overlay-center card-img-overlay-bg">
                            			<ul class="social-list">
                                			<li><a href="#"><i class="icon-twitter icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-facebook icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-linkedin icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-google-plus icon-size-m"></i></a></li>
                            			</ul>
                        			</div>
                        			<img class="card-img" src="images/team-2.jpg" srcset="images/team-2@2x.jpg 2x" alt="équipe">
                    			</div>
                    			<div class="card-block">
                        			<h4 class="mt-20 mb-0"><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Laura O'Neil</font></font></strong></h4>
                        			<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Directeur</font></font></p>
                    			</div>
                			</div>

            			</div>
            			<div class="col-md-3">
                			<div class="card">
                    			<div class="card-block-hover">
                        			<div class="card-img-overlay-center card-img-overlay-bg">
                            			<ul class="social-list">
                                			<li><a href="#"><i class="icon-twitter icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-facebook icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-linkedin icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-google-plus icon-size-m"></i></a></li>
                            			</ul>
                        			</div>
                        			<img class="card-img" src="images/team-1.jpg" srcset="images/team-1@2x.jpg 2x" alt="équipe">
                    			</div>
                    			<div class="card-block">
                        			<h4 class="mt-20 mb-0"><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Michael Smith</font></font></strong></h4>
                        			<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Designer</font></font></p>
                    			</div>
                			</div>
                			<div class="card">
                    			<div class="card-block-hover">
                        			<div class="card-img-overlay-center card-img-overlay-bg">
                            			<ul class="social-list">
                                			<li><a href="#"><i class="icon-twitter icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-facebook icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-linkedin icon-size-m"></i></a></li>
                                			<li><a href="#"><i class="icon-google-plus icon-size-m"></i></a></li>
                            			</ul>
                        			</div>
                        			<img class="card-img" src="images/team-3.jpg" srcset="images/team-3@2x.jpg 2x" alt="équipe">
                    			</div>
                    			<div class="card-block">
                        			<h4 class="mt-20 mb-0"><strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Katy Davis</font></font></strong></h4>
                        			<p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Programmeur</font></font></p>
                    			</div>
                			</div>
            			</div>
        			</div>
    			</div>
    			<div class="bg"></div>
			</section>

            <?php
            include "footer.php";
            ?>
		</div>
		<footer></footer>
		<div class="modal-container"></div>
		<script src="js/jquery-2.1.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.vide.min.js"></script>
		<script src="js/owl.carousel.js"></script>
		<script src="js/jquery.magnific-popup.min.js"></script>
		<script src="js/jquery.validate.min.js"></script>
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCByts0vn5uAYat3aXEeK0yWL7txqfSMX8"></script>
		<script src="https://cdn.jsdelivr.net/jquery.goodshare.js/3.2.8/goodshare.min.js"></script>
		<script src="js/custom.js"></script>
		<script src="js/profil.js"></script>
	</body>
</html>