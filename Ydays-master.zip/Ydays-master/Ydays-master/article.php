<!-- page article crée à titre d'exemple pour poster ses articles(avec titre, description et image) et redirigée vers la page traitement.php, où il est affiché -->
<?php
include "connexionbdd.php";

?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <title>Articles</title>

        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <script src="http://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js"></script>
        <script src="js/fonts.js"></script>
        <link rel="stylesheet" href="css/bootstrap.css" />
        <link rel="stylesheet" href="css/icons.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="css/owl.carousel.css" />
        <link rel="stylesheet" href="css/magnific-popup.css" />
        <link rel="stylesheet" href="css/custom.css" />
        <link rel="stylesheet" href="css/inscription.css" />
    </head>
    <body class="dark-page">
    <div id="preloader"><div class="circles"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>

    <?php
    include "header.php";
    ?>
    <div id="wrap">
        <section id="contact-quartbg-form-text--3" class="pt-md-150 pb-150 bg-1-color-light light">
            <div class="quarter-container-left"></div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4 col-md-offset-4">
                        <h2 class="mb-50"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Mettre l'article en ligne</font></font></h2>
                        <!-- formulaire qui redirige vers la page traitement.php -->
                        <form action="traitement.php" enctype="multipart/form-data" method="post" class="contact_form" id="contact-quartbg-form-text--3-form" novalidate="novalidate" method="post">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Titre de l'article" name="titre">
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" rows="6" placeholder="Texte de l'article" name="description"></textarea>
                                <!-- <input type="text" class="form-control" placeholder="Texte de l'article" name="description"> -->
                            </div>
                            <div class="form-group">
                                <input type="file" class="form-control" name="image">
                            </div>
                            <button type="submit" data-loading-text="•••" data-complete-text="Completed!" data-reset-text="Try again later..." class="btn btn-block btn-primary"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Confirmer</font></font></span></button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="bg"></div>
        </section>
    </div>
    <?php
    include "footer.php";
    ?>

    </div>
    <footer></footer>
    <div class="modal-container"></div>
    <script src="js/jquery-2.1.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.vide.min.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCByts0vn5uAYat3aXEeK0yWL7txqfSMX8"></script>
    <script src="https://cdn.jsdelivr.net/jquery.goodshare.js/3.2.8/goodshare.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/inscription.js"></script>
    </body>
    </html>
