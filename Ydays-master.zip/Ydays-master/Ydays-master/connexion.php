<?php

require("connexionbdd.php");

#A revoir
include "header.php";


/*if(isset($_POST) and isset($_POST['password'])){
    $requete = $dbh->prepare('SELECT * from utilisateurs where pseudo=? and password=?');

    $requete->execute([$_POST['pseudo'], sha1(md5(($_POST['password'])))]);

    $catch = $requete->fetch();
    if(isset($catch['id_utilisateur'])) {
        $_SESSION['user-connecté'] = $catch['id_utilisateur'];
        echo "connexion réussie";
        #header('Location: user.php');
        header('Location: user.php?'.$catch['pseudo']);
    } else {
        echo "mauvais mot de passe ou mauvais identifiant";
    }
}*/
if (!empty($_POST)) {

    $req = $dbh->prepare('SELECT * FROM utilisateurs 
                   WHERE pseudo = :pseudo 
                   AND password = :password');
    $req->execute([
        ':pseudo' => $_POST['pseudo'],
        ':password' => sha1(md5($_POST['password']))
    ]);
    $users = $req->fetchAll();

    if(count($users) > 0){
        $_SESSION['connected'] = true;
        $_SESSION['id_utilisateur'] = $users[0]['id_utilisateur'];
        header('Location:index.php');
    } else {

        header('location:inscription.php');
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>

    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <script src="http://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js"></script>
    <script src="js/fonts.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/icons.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/owl.carousel.css" />
    <link rel="stylesheet" href="css/magnific-popup.css" />
    <link rel="stylesheet" href="css/custom.css" />
    <link rel="stylesheet" href="css/connexion.css" />
</head>
<body class="dark-page">

<div id="preloader"><div class="circles"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div></div>




<div id="wrap">
    <section id="contact-halfbg-form" class="pt-md-125 pb-125 bg-1-color-light light">
        <div class="half-container-left"></div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4 col-md-offset-7">
                    <h2 class="mb-20"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Connecter-vous </font></font></font></font></font></font></font></font></h2>

                    <form action="" method="post" class="contact_form" novalidate="novalidate" id="contact-halfbg-form-form">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="pseudo" name="pseudo">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Mot de passe" name="password">
                        </div>
                        <button type="submit" data-loading-text="•••" data-complete-text="Completed!" data-reset-text="Try again later..." class="btn btn-primary"><span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Se Connecter</font></font></font></font></font></font></font></font></span></button>
                    </form>
                </div>
            </div>
        </div>
        <div class="bg"></div>
    </section>
</div>
<?php
include "footer.php";
?>
<footer></footer>
<div class="modal-container"></div>
<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.vide.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCByts0vn5uAYat3aXEeK0yWL7txqfSMX8"></script>
<script src="https://cdn.jsdelivr.net/jquery.goodshare.js/3.2.8/goodshare.min.js"></script>
<script src="js/custom.js"></script>
<script src="js/connexion.js"></script>
</body>
</html>

<!--<?php

?>

<!-- Avec mon formulaire, ca passe
<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styles.css" type="text/css">
    <title>Connexion</title>
</head>
<body>
<div id="header">

</div>
<nav>
    <ul>
        <li><a href="connexion.php">Connexion</a></li>
        <li><a href="inscription.php">Inscription</a></li>
    </ul>
</nav>
<div id="sidebar">
    <h1>Connexion</h1>
    <form method="post" action="connexion.php">
        <label for="pseudo">Pseudo</label><input name="pseudo" type="text" /><br>
        <label for="password">*Mot de passe</label><input name="password" type="password" /><br>
        <button type="submit">Se connecter</button>
    </form>
    Pas encore inscrit? <a href="inscription.php">S'Inscrire Ici</a>
</div>
<div class="post">
</div>
<div class="post">
</div>
<div id="footer">

</div>

<!--<!--<script type="text/javascript" src="manga-projet/js/fonts.js"></script>-->

<!-- <footer>
    <small>Copyright 2017</small>
</footer>
</body>
</html> -->
