<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors',1);
/* Connexion à une base ODBC avec l'invocation de pilote */
$dsn = 'mysql:host=localhost;dbname=mangas';
$user = 'root';
$password = '';
try {
    $dbh = new PDO($dsn, $user, $password);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connexion échouée : ' . $e->getMessage();
}